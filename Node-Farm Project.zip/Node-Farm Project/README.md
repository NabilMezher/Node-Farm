# Node Farm

This project was done by me from a bootcamp I took in Node.js, Express.js, MongoDB.

The idea of the project is to create a simple website for a farm.

In this project, I learned all about the basics of Node.js from routing, npm, modules, HTML templating: building and filling the templates,
including working with the modules like URL.
